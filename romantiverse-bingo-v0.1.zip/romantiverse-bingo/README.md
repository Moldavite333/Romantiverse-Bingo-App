# Romantiverse Bingo — standalone prototype v0.1
**Brought to you by Cheese Louise Podcast**

## Start
`npm install` then `npm run dev`. Open the local URL Vite displays.

## Tests
`npm test` runs deterministic game-engine tests. `npm run build` typechecks and builds the app.

## What is implemented
- Standalone responsive React prototype
- Three **fictional demo movies** (not a Hallmark catalog)
- Manual movie title and seasonal pack selection
- Seeded deterministic 5×5 card generation; free-center option
- Tap-to-mark/unmark, 12-line Bingo detection
- Automatic browser-local progress saving
- Cheese Louise attribution in header and footer

## Not yet implemented
- Actual Hallmark catalog ingestion, TMDB integration, artwork rights
- AI synopsis/poster/review analysis; current clue detection is simple keyword matching
- Shared accounts, server persistence, multiplayer, authoritative scoring, reconnect recovery
- Accessibility audit, cross-browser device testing, game-balance simulation, production security review

## Architecture roadmap
Move engine into shared package; introduce versioned movie and trope records; snapshot immutable cards; add Supabase with row-level security and server-side idempotent game actions; real-time rooms and replayable event log; run integration and end-to-end tests before deployment.

**Warning:** Current demo saves only to the same browser. Clearing browser data removes progress.
