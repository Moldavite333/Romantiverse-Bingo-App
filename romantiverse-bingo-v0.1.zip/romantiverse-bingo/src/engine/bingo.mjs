export const LINES = Object.freeze([
  ...Array.from({length:5},(_,r)=>Array.from({length:5},(_,c)=>r*5+c)),
  ...Array.from({length:5},(_,c)=>Array.from({length:5},(_,r)=>r*5+c)),
  [0,6,12,18,24],[4,8,12,16,20]
]);
export function random(seed){let s=seed>>>0;return ()=>{s=(s+0x6D2B79F5)>>>0;let t=Math.imul(s^(s>>>15),1|s);t^=t+Math.imul(t^(t>>>7),61|t);return ((t^(t>>>14))>>>0)/4294967296}}
export function deal(pool,seed,free=true){if(!Number.isSafeInteger(seed)||seed<0)throw Error('Invalid seed');const count=free?24:25;const unique=[...new Set(pool.filter(x=>typeof x==='string'&&x.trim()).map(x=>x.trim()))];if(unique.length<count)throw Error(`Need ${count} unique tropes`);const rng=random(seed);for(let i=unique.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[unique[i],unique[j]]=[unique[j],unique[i]]}const cards=unique.slice(0,count);if(free)cards.splice(12,0,'FREE');return cards}
export function winningLines(marked,free=true){const set=new Set(marked);if(free)set.add(12);return LINES.filter(line=>line.every(i=>set.has(i)))}
export function toggle(marked,index,free=true){if(!Number.isInteger(index)||index<0||index>24)throw Error('Invalid square');if(free&&index===12)return [...new Set(marked)];const set=new Set(marked);set.has(index)?set.delete(index):set.add(index);return [...set].sort((a,b)=>a-b)}
export function score(marked,free=true){return {marked:new Set(marked).size,lines:winningLines(marked,free).length,bingo:winningLines(marked,free).length>0}}
